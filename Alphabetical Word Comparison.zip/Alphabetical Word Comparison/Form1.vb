﻿Public Class Form1
    'Assignment 5
    'Class - CSC 101-53
    'Name - Isabella Villas
    'Purpose - Compare the unicode values of two words
    Private Sub btnCompare_Click(sender As Object, e As EventArgs) Handles btnCompare.Click
        If txtWord1.Text > txtWord2.Text Then
            lblMessage.Text = "Word 1 is greater than Word 2"
            ' Compares the values of both words, then if word 1 is greater than word 2, a message tells the user so
        ElseIf txtWord2.Text > txtWord1.Text Then
            lblMessage.Text = "Word 1 is less than Word 1"
            ' Compares the value of both words, then if word 1 is less than word 2, the label tells the user so
        ElseIf txtWord1.Text = String.Empty And txtWord2.Text = String.Empty Then
            ' if both words are empty the user is given an error to input both words
            MessageBox.Show("Error: enter both the words", "Error Message")
        Else
            lblMessage.Text = "Word 1 and Word 2 are equal"
            ' if both words are equal, a message tells the user so
        End If
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        txtWord1.Focus()
        ' When cleared, word 1 is the first thing the user must edit
        txtWord2.Text = ""
        ' Word 2 is cleared when clear button is pressed
        lblMessage.Text = ""
        ' Label is cleared when clear button is pressed
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
        'Closes the application
    End Sub
End Class
